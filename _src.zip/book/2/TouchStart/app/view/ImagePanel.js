Ext.define('TouchStart.view.ImagePanel', {
    extend: 'Ext.Container',
    xtype: 'imagepanel',
    config: {
		title: 'Image',
		fullscreen: false,
		html: 'Big image goes here!',
		iconCls: 'favorites'
    }
});